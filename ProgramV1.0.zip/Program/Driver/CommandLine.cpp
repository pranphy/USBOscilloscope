
#include<usb.h>
#include<cstdio>
#include<cstring>
#include<iostream>
#include<iomanip>

using namespace std;

#define USB_LED_OFF 				0
#define USB_LED_ON  				1
#define USB_DATA_OUT				2

static int usbGetDescriptorString(usb_dev_handle*, int, int,char*,int);
static usb_dev_handle* usbOpenDevice(int,char*,int,char*);



int main(int argc, char **argv) 
{
    usb_dev_handle *handle = NULL;
    int i=0;
    unsigned short TestValue;
    int nBytes = 0;
    char buffer[256];

    if(argc < 2)
    {
        cout<<"Argument Missing :-"<<endl;
        exit(1);
    }

    handle = usbOpenDevice(0x16C0, const_cast<char*>("PRANPHY-CORRUPT"), 0x03E8,const_cast<char*>("OSCILLOSCOPE"));

    if(handle == NULL) 
    {
        fprintf(stderr, "Could not find USB device!n \n");
        exit(1);
    }

    if(strcmp(argv[1], "on") == 0)
        nBytes = usb_control_msg(handle,USB_TYPE_VENDOR | USB_RECIP_DEVICE | USB_ENDPOINT_IN,USB_LED_ON, 0, 0, (char *)buffer, sizeof(buffer), 5000);
	else if(strcmp(argv[1], "off") == 0) 
        nBytes = usb_control_msg(handle,USB_TYPE_VENDOR | USB_RECIP_DEVICE | USB_ENDPOINT_IN,USB_LED_OFF, 0, 0, (char *)buffer, sizeof(buffer), 5000);
    else if(strcmp(argv[1], "out") == 0) 
    {
        nBytes = usb_control_msg(handle,USB_TYPE_VENDOR | USB_RECIP_DEVICE | USB_ENDPOINT_IN,USB_DATA_OUT, 0, 0, (char *)buffer, sizeof(buffer), 5000);
        printf("Got %d bytes: %s", nBytes, buffer);
	}
	for(;;)
	{
		for(i=0;i<9999999;i++);
		
		nBytes = usb_control_msg(handle,USB_TYPE_VENDOR | USB_RECIP_DEVICE | USB_ENDPOINT_IN,USB_DATA_OUT, 0, 0, (char *)buffer, sizeof(buffer), 5000);
		TestValue=static_cast<unsigned short>(buffer[0]);
		cout<<hex<<TestValue<<endl;
        printf(" Got %d bytes: %d \n", nBytes, TestValue);
        
	}
    if(nBytes < 0)
        fprintf(stderr, "USB error: %sn", usb_strerror());
    usb_close(handle);
    return 0;
}



static int usbGetDescriptorString(usb_dev_handle *dev, int index, int langid,char *buf, int buflen) 
{
    char buffer[256];
    int rval, i;

    // make standard request GET_DESCRIPTOR, type string and given index 
    // (e.g. dev->iProduct)
    rval = usb_control_msg(dev,USB_TYPE_STANDARD | USB_RECIP_DEVICE | USB_ENDPOINT_IN,USB_REQ_GET_DESCRIPTOR, (USB_DT_STRING << 8) + index, langid,buffer, sizeof(buffer), 1000);
    if(rval < 0) // error
        return rval;

    // rval should be bytes read, but buffer[0] contains the actual response size
    if((unsigned char)buffer[0] < rval)
        rval = (unsigned char)buffer[0]; // string is shorter than bytes read

    if(buffer[1] != USB_DT_STRING) // second byte is the data type
        return 0; // invalid return type

    // we're dealing with UTF-16LE here so actual chars is half of rval,
    // and index 0 doesn't count
    rval /= 2;

    /* lossy conversion to ISO Latin1 */
    for(i = 1; i < rval && i < buflen; i++) 
    {
        if(buffer[2 * i + 1] == 0)
            buf[i-1] = buffer[2 * i];
        else
            buf[i-1] = '?'; /* outside of ISO Latin1 range */
    }
    buf[i-1] = 0;

    return i-1;
}



static usb_dev_handle * usbOpenDevice(int vendor, char *vendorName, int product, char *productName) 
{
    struct usb_bus *bus;
    struct usb_device *dev;
    char devVendor[256], devProduct[256];

    usb_dev_handle * handle = NULL;

    usb_init();
    usb_find_busses();
    usb_find_devices();

    for(bus=usb_get_busses(); bus; bus=bus->next) 
    {
        for(dev=bus->devices; dev; dev=dev->next) 
        {                     
            if(dev->descriptor.idVendor != vendor || dev->descriptor.idProduct != product)
                continue;
            if(!(handle = usb_open(dev))) 
            {
                fprintf(stderr, "Warning: cannot open USB device: %sn", usb_strerror());
                continue;
            }
            if(usbGetDescriptorString(handle, dev->descriptor.iManufacturer,0x0409, devVendor, sizeof(devVendor)) < 0) 
            {
                fprintf(stderr,"Warning: cannot query manufacturer for device: %sn",usb_strerror());
                usb_close(handle);
                continue;
            }
            if(usbGetDescriptorString(handle, dev->descriptor.iProduct,0x0409, devProduct, sizeof(devVendor)) < 0)
            {
                fprintf(stderr,"Warning: cannot query product for device: %sn", usb_strerror());
                usb_close(handle);
                continue;
            }
            if(strcmp(devVendor, vendorName) == 0 && strcmp(devProduct, productName) == 0)
                return handle;
            else
                usb_close(handle);
        }
    }
    return NULL;
}

